module.exports = {
    plugins: [require('prettier-plugin-tailwindcss')],
    "printWidth": 140,
}