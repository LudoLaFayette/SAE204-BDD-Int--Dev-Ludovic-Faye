<template>
  <div class="flex flex-col bg-fond">
    <div class="flex">
      <img src="../../images/image_8.webp" class="w-full" />
    </div>
    <!-- Changement de page pour correction à la maquette : plus de card ici -->
    <div class="flex items-center justify-center gap-2.5 p-2.5">
      <div class="mx-[5rem] mt-[-70px] flex rounded-[25px] border-2 border-couleur-red-600 bg-fond px-[35px] py-1">
        <h2 class="relative text-center font-alegreya-sans lg:text-8xl md:text-6xl text-2xl font-bold text-couleur-red-600">Yyes Jamait</h2>
      </div>
    </div>
    <div class="flex flex-col gap-2 m-auto justify-center">
      <p class="flex mx-7 my-7 leading-normal text-2xl font-alegreya-sans text-text">
        Courte Biographie de Yves Jamait : Yves Jamait est né à Dijon en 1961. Il se destine tout d’abord à la cuisine, exerce plusieurs
        métiers, tout en s’adonnant à la guitare. C'est en 2001 qu'il sort son premier album De Verre en Vers avec son trio sous le nom
        deJamait . Repéré très vite pour ses talents d’écriture,Yves Jamait reçoit un accueil chaleureux du public et sort son 2éme album Le
        coquelicot . Musicien, amoureux de poésie et du répertoire de ses aînés, il s’inscrit dans la tradition de la chanson française. Il
        participe aux festivals qui célèbrent ce répertoire tels que les Francofolies , les Nuits de Champagne ou encore Alors... chante .
        Son troisième album Je passais par hasard , à l’instar des précédents, sera certifé disque d’or . En tournée, il crée les Bars à
        Jamait dans lesquels il convie ses amis chanteurs oubliés par le circuit médiatique. Très attaché à sa région d’origine, il
        participe à de nombreuses manifestations locales. Saison 4 sort en 2011. S’en suivra une saison de tournée qui passe notamment par
        le Grand Rex en avril 2012.
      </p>
      <div class="flex justify-center mb-[45px]">
        <img src="../../images/image_7.webp" class="w-[50%] " />
      </div>
    </div>
  </div>
</template>
<script>
</script>