<template>
  <div class="flex flex-col bg-fond">
    <div class="flex">
      <img src="../../images/image-3.webp" class="w-full" />
    </div>
    <!-- Changement de page pour correction à la maquette : plus de card ici -->
    <div class="flex items-center justify-center gap-2.5 p-2.5">
      <div class="mx-[5rem] mt-[-70px] flex rounded-[25px] border-2 border-couleur-red-600 bg-fond py-1 text-2xl md:text-4xl">
        <h2 class="relative text-center font-alegreya-sans text-2xl font-bold text-couleur-red-600 md:text-6xl lg:text-8xl">Histoire</h2>
      </div>
    </div>
    <div class="mb-[45px] mt-[45px] p-5">
      <p class="text-center font-alegreya-sans text-2xl text-text md:text-3xl">
        Voici la partie du site ou vous pourrez découvrir l’histoire du festival. Un festival qui prend place dans un cadre unique, au coeur
        de la ville de Sens. Le marché couvert, inauguré en 1882, est un exemple typique de l’architecture métallique du XIXe siècle : cette
        halle couverte de forme triangulaire, de style Baltard, constitue l’un des rares modèles de ce type en France. En 2015, l’édifice a
        été rénové et a retrouvé sa splendeur d’antan.
      </p>
    </div>
    <div class="mb-[45px] mt-[45px] p-5">
      <img src="../../images/image_2_1_.webp" class="w-full" />
      <p class="text-center font-alegreya-sans text-2xl text-text md:text-3xl">
        Ce lieu a été choisi, car son style d’architecture, abrite un interieur riche en emplacement de commerces et d’une scène centrale,
        dont il est possible de créer une scène locale. Les chanteurs qui se sont rendues sur cette scène, peuvent se rappeler de la
        résonnance de l’endroit, unique en son genre. Depuis 20 éditions, le festival peut vibrer en intérieur comme en exterieur avec la
        place de la cathédrale ainsi que les rues adjacantes qui acceuille les groupes locales lors de l’évènement “Garcon la note” en
        complément.
      </p>
      <img src="../../images/image_4.webp" class="w-full" />
    </div>
  </div>
</template>
<script>
</script>