<template>
  <div class="flex flex-col bg-fond">
    <div class="flex">
      <img src="../../images/Image-1-1-_1_.webp" class="w-full" />
    </div>
    <!-- Changement de page pour correction à la maquette : plus de card ici -->
    <div class="flex items-center justify-center p-2.5">
      <div class="mx-[5rem] mt-[-70px] flex rounded-[25px] border-2 border-couleur-red-600 bg-fond px-[35px] py-1">
        <h2 class="relative text-center font-alegreya-sans lg:text-8xl md:text-6xl text-2xl font-bold text-red-600">"Jamait Ici"</h2>
      </div>
    </div>
    <div class="flex items-center justify-center p-[40px] gap-[80px] mb-[45px]">
      <div class="flex items-center gap-[40px]">
        <div class="inline-block align-top">
          <img src="../../images/image_4.webp" class="w-[100%]" />
        </div>
        <div class="inline-block text-right font-alegreya-sans text-2xl text-text">
          <p>
            Lieu du Concert : Scène intérieure des Halles <br />
            Date de concert : Passage le lundi 18 juillet entre 14h30 et 16h30
          </p>
        </div>
      </div>

      <div class="flex items-center gap-[25px]">
        <div class="clear-left text-left text-2xl inline-block font-alegreya-sans text-text">
          <p>
            Artiste : Yyes Jamait <br />
            Style : Guitare et variété française <br />
            Local ? : Vient de Dijon
          </p>
        </div>
        <div class="float-right inline-block">
          <img src="../../images/image_8.webp" class="w-[100%]" />
        </div>
      </div>
    </div>
  </div>
</template>
<script>
</script>