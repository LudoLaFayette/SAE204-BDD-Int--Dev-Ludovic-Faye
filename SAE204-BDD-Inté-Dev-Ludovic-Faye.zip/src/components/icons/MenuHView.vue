<template>
    <div
  class="flex justify-end items-center w-[59.84px] relative overflow-hidden gap-2.5 px-2.5 pt-3 pb-[17px]"
>
  <svg
    width="41"
    height="40"
    viewBox="0 0 41 74"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="self-stretch flex relative"
    preserveAspectRatio="none"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M6.60889 25.9C6.60889 23.8566 7.50066 22.2 8.60071 22.2H32.5026C33.6026 22.2 34.4944 23.8566 34.4944 25.9C34.4944 27.9435 33.6026 29.6 32.5026 29.6H8.60071C7.50066 29.6 6.60889 27.9435 6.60889 25.9Z"
      fill="#111827"
    ></path>
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M6.60889 48.1C6.60889 46.0566 7.50066 44.4 8.60071 44.4H32.5026C33.6026 44.4 34.4944 46.0566 34.4944 48.1C34.4944 50.1435 33.6026 51.8 32.5026 51.8H8.60071C7.50066 51.8 6.60889 50.1435 6.60889 48.1Z"
      fill="#111827"
    ></path>
  </svg>
</div>

</template>