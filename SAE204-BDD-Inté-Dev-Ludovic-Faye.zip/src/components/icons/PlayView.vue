<template>
  
    <svg
      width="120"
      height="120"
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class="justify-center "
      preserveAspectRatio="none"
    >
      <circle cx="60" cy="60" r="59.5" stroke="white"></circle>
      <path d="M52.5 34.392L79.2559 58.6667L52.5 82.9413V34.392Z" fill="white" stroke="white"></path>
    </svg>
 
</template>