<template>
  <div class="flex items-center justify-between px-[9px]">
    <div class="relative flex h-[67px] items-center justify-start gap-[15px] py-5">
      <div class="h-[53.26px] w-[67.16px] ">
        <div class="h-[53.26px] w-[67.16px]">
          <svg
            width="68"
            height="57"
            viewBox="0 0 68 57"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            class="absolute left-[-1px] top-[5.87px]"
            preserveAspectRatio="none"
          >
            <path
              d="M0.52041 16.5122L10.7105 2.86401C10.9431 2.55398 11.2406 2.3034 11.5802 2.13136C11.9199 1.95932 12.2927 1.87037 12.6704 1.87128H54.5408C54.915 1.87309 55.284 1.96337 55.6199 2.13533C55.9558 2.30728 56.25 2.55643 56.4801 2.86401L66.6428 16.4336C66.9259 16.8162 67.1015 17.2732 67.1499 17.7537C67.1983 18.2342 67.1176 18.7192 66.9169 19.1547L50.8951 53.7001C50.6868 54.134 50.3655 54.4981 49.968 54.7507C49.5706 55.0033 49.1129 55.1342 48.6474 55.1285L17.0698 54.9143C16.5932 54.9104 16.1278 54.7635 15.7292 54.4912C15.3306 54.2189 15.0157 53.8327 14.8221 53.3787L0.205183 19.1261C0.0280864 18.701 -0.0360923 18.2341 0.0193648 17.7742C0.0748219 17.3143 0.247875 16.8785 0.52041 16.5122V16.5122Z"
              stroke="#728CA8"
              stroke-width="2"
              stroke-miterlimit="10"
            ></path>
          </svg>
          <p class="absolute left-[3.23px] top-[15.53px] h-[10.68px] w-[6.19px] text-left text-[12.014737129211426px] text-[#1d1d1b]">A</p>
          <p class="absolute left-[34.06px] top-[20.93px] h-[10.7px] w-[6.17px] text-left text-[11.99302864074707px] text-[#1d1d1b]">A</p>
          <p class="absolute left-[40.55px] top-[19.79px] h-[10.7px] w-[4.8px] text-left text-[11.99302864074707px] text-[#1d1d1b]">L</p>
          <p class="absolute left-[45.93px] top-[18.91px] h-[10.7px] w-[4.8px] text-left text-[11.99302864074707px] text-[#1d1d1b]">L</p>
          <p class="absolute left-[51.13px] top-[17.81px] h-[10.7px] w-[5.49px] text-left text-[11.99302864074707px] text-[#1d1d1b]">E</p>
          <p class="absolute left-[57.75px] top-[16.56px] h-[10.7px] w-[5.49px] text-left text-[11.99302864074707px] text-[#1d1d1b]">S</p>
          <p class="absolute left-[9.82px] top-[17.72px] h-[10.69px] w-[6.18px] text-left text-[11.986014366149902px] text-[#1d1d1b]">U</p>
          <p class="absolute left-[17.69px] top-[17.97px] h-[13.52px] w-[6.88px] text-left text-[15.291482925415039px] text-[#1d1d1b]">X</p>
          <p class="absolute left-[23.78px] top-[20.65px] h-[12.84px] w-[8.23px] text-left text-[15.263854026794434px] text-[#1d1d1b]">H</p>
        </div>
      </div>
    </div>
  </div>
</template>